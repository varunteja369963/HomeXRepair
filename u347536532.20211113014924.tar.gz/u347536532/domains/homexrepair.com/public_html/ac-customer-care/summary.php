<section class="lp3-summary-section">
    <div class="lp3-summary lp3-fridge-summary">
        <img class="lp3-summary-fridge-image" title = "AC Repair & Services" srcset="ac-customer-care_mobile.jpg 400w,
             https://homexrepair.com/img/ac-customer-care_desktop.jpg 800w" sizes="(max-width: 500px) 400px,
            800px" src="https://homexrepair.com/img/ac-customer-care_desktop.jpg" alt="AC (Air Conditioner) Repair Service In Hyderabad">
        <div class="lp3-banner-black-background">
    <div class="lp3-banner-black-background-inner"> 
        <h1 class="heading fridge-heading">Air Conditioner(AC) Customer Care Service</h1>
          <ul class="fridge-summary-ul">
                <li>90 days guarantee on parts</li>
                <li>Labour charge only at Rs. 449</li>
  <li class="fridge-last-li">Doorstep repair on same day</li>
            </ul>
       </div>
</div>
    </div>
</section>