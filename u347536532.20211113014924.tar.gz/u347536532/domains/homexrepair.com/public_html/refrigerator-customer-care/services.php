<section itemscope="" itemtype="http://schema.org/Service" class="lp3-service-section">
<div class="service-section-label"><p>Repair services in refrigerator</p></div>
<div class="lp3-three-service-frames">
<div class="lp3-service-frame service-frame1">
<div itemprop="itemOffered" itemscope="" itemtype="http://schema.org/Service" class="lp3-service-frame-inner">
<div class="service-image">
<a href="#"><img itemprop="image" alt="Single door fridge customer care" title = "single door fridge (refrigerator) customer care" src="https://homexrepair.com/img/single-door-refrigerator-customer-care.png"></a>
</div>
  <div class="service-label"><p itemporp="name">Single door refrigerator customer care</p></div>
<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button" itemscope="" itemtype="http://schema.org/LocalBusiness"><a itemprop="telephone" href="tel:1800-833-0206">CALL NOW</a></div>

</div>
</div>
</div>
<div class="lp3-service-frame service-frame2">
<div itemprop="itemOffered" itemscope="" itemtype="http://schema.org/Service" class="lp3-service-frame-inner">
<div class="service-image">
<a href="#"><img itemprop="image" alt="Double door fridge customer care" title = "Double door fridge (refrigerator) customer care" src="https://homexrepair.com/img/double-door-refrigerator-customer-care.png"></a>
</div>
  <div class="service-label"><p itemporp="name">Double door refrigerator customer care</p></div>
<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button" itemscope="" itemtype="http://schema.org/LocalBusiness"><a itemprop="telephone" href="tel:1800-833-0206">CALL NOW</a></div>
</div>
</div>
</div>

<div class="lp3-service-frame service-frame3">
<div itemprop="itemOffered" itemscope="" itemtype="http://schema.org/Service" class="lp3-service-frame-inner">
<div class="service-image top-load-image">
<a href="#"><img itemprop="image" alt="Side by side door fridge customer care" title="Side by side door fridge (refrigerator) customer care" src="https://homexrepair.com/img/side-by-side-door-refrigerator-customer-care.png"></a>
</div>
<div class="service-label"><p itemporp="name">Side by side door refrigerator customer care</p></div>

<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button" itemscope="" itemtype="http://schema.org/LocalBusiness"><a itemprop="telephone" href="tel:1800-833-0206">CALL NOW</a></div>

</div>
</div>
</div>
</div>
</section>