<section class="lp3-summary-section">
    <div class="lp3-summary lp3-fridge-summary">
        <img title = "fridge customer care, refrigerator customer care number" class="lp3-summary-fridge-image" srcset="https://homexrepair.com/img/fridge-customer-care_mobile.webp 400w,
             https://homexrepair.com/img/fridge-customer-care_desktop.webp 800w" sizes="(max-width: 500px) 400px,
            800px" src="https://homexrepair.com/img/fridge-customer-care_desktop.webp" alt="Fridge (refrigerator) customer care number Hyderabad">
        <div class="lp3-banner-black-background">
    <div class="lp3-banner-black-background-inner"> 
        <h1 class="heading fridge-heading">Refrigerator (fridge) Customer Care Service In Hyderabad</h1>
          <ul class="fridge-summary-ul">
                <li>90 days guarantee on parts</li>
                <li>Labour charge only at Rs. 259</li>
  <li class="fridge-last-li">Doorstep repair on same day</li>
            </ul>
       </div>
</div>
    </div>
</section>