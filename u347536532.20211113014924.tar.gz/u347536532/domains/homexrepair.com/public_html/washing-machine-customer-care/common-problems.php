<section class = "common-problems">
 <div class = "common-problems-div">
     <div class = "common-poblems-label">
     <h1>Most Common Washing Machine Problems And How To Solve Them?</h1>
     </div>
     
     <div class = "commont-problems-inner">
         <div class = "common-problems-box">
             <div class = "common-problems-question-div">
                <div class = "common-problems-question"><h2></h2></div>
                <div class = "common-problems-up-down-arrow" id = "common-problems-up-down-arrow" data-question = "1" ></div>
             </div>
             <div class = "commont-problems-solution">
                 <p></p>
             </div>
         </div>
     </div>
 </div>   
</section>