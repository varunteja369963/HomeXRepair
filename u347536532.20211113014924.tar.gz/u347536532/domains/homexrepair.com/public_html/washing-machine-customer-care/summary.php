<section class="lp3-summary-section">
    <div class="lp3-summary lp3-fridge-summary">
<!--
        <img class="lp3-summary-fridge-image" title = "Washing Machine Customer Care In Hyderabad" srcset="https://homexrepair.com/img/washing-machine-customer-care-mobile.jpg 400w,
             https://homexrepair.com/img/washing-machine-customer-care-desktop.jpg 800w" sizes="(max-width: 500px) 400px,
            800px" src="https://homexrepair.com/img/washing-machine-customer-care-mobile.jpg" alt="Washing Machine Customer Care"></img>
      -->  
      <img class = "lp3-summary-fridge-image" srcset="https://homexrepair.com/img/washing-machine-customer-care-hyderabad_mobile.webp 400w, https://homexrepair.com/img/washing-machine-customer-care-hyderabad_desktop.webp 800w" sizes="(max-width: 500px) 400px,
            800px" src="https://homexrepair.com/img/washing-machine-customer-care-hyderabad_desktop.webp" title = "Washing Machine Customer Care In Hyderabad" alt="Washing Machine Customer Care">
            
        <div class="lp3-banner-black-background">
    <div class="lp3-banner-black-background-inner"> 
        <h1 class="heading fridge-heading">Washing Machine Customer Care In Hyderabad</h1>
          <ul class="fridge-summary-ul">
                <li>90 days guarantee on parts</li>
                <li>Labour charge only at Rs. 249</li>
  <li class="fridge-last-li">Doorstep repair on same day</li>
            </ul>
       </div>
</div>
    </div>
</section>
