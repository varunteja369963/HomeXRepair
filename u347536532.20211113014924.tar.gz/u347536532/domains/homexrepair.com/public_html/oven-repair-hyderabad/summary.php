<section class="lp3-summary-section">
    <div class="lp3-summary lp3-fridge-summary">
        <img class="lp3-summary-fridge-image" srcset="https://homexrepair.com/img/oven-repair-service_mobile.webp 400w,
             https://homexrepair.com/img/oven-repair-service_desktop.webp 800w" sizes="(max-width: 500px) 400px,
            800px" src="https://homexrepair.com/img/oven-repair-service_desktop.webp" alt="Best Microwave Oven Repair Service Center In Hyderabad">
        <div class="lp3-banner-black-background">
    <div class="lp3-banner-black-background-inner"> 
        <h1 class="heading fridge-heading">Microwave Oven Repair Service In Hyderabad</h1>
          <ul class="fridge-summary-ul">
                <li>90 days guarantee on parts</li>
                <li>Labour charge only at Rs. 249</li>
  <li class="fridge-last-li">Only genuine parts used</li>
            </ul>
       </div>
</div>
    </div>
</section>