<section class="lp3-summary-section">
    <div class="lp3-summary lp3-fridge-summary">
        <img class="lp3-summary-fridge-image" srcset="https://homexrepair.com/img/refrigerator-repair-service_mobile.jpg 400w,
             https://homexrepair.com/img/refrigerator-repair-service_desktop.jpg 800w" sizes="(max-width: 500px) 400px,
            800px" src="https://homexrepair.com/img/refrigerator-repair-service_desktop.jpg" alt="Best Fridge Repair Service Center In Hyderabad">
        <div class="lp3-banner-black-background">
    <div class="lp3-banner-black-background-inner"> 
        <h1 class="heading fridge-heading">No.1 Refrigerator Repair Service In Hyderabad</h1>
          <ul class="fridge-summary-ul">
                <li>90 days guarantee on parts</li>
                <li>Labour charge only at Rs. 249</li>
  <li class="fridge-last-li">Doorstep repair on same day</li>
            </ul>
       </div>
</div>
    </div>
</section>