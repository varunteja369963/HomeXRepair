<section itemscope="" itemtype="http://schema.org/Service" class="lp3-service-section">
<div class="service-section-label"><p>Repair services in refrigerator</p></div>
<div class="lp3-three-service-frames">
<div class="lp3-service-frame service-frame1">
<div itemprop="itemOffered" itemscope="" itemtype="http://schema.org/Service" class="lp3-service-frame-inner">
<div class="service-image">
<a href="#"><img itemprop="image" alt="Front door Fridge repair" src="https://homexrepair.com/img/single-door-fridge-repair.png"></a>
</div>
  <div class="service-label"><p itemporp="name">Front door refrigerator repair</p></div>
<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button" itemscope="" itemtype="http://schema.org/LocalBusiness"><a itemprop="telephone" href="tel:18008330206">CALL NOW</a></div>

</div>
</div>
</div>
<div class="lp3-service-frame service-frame2">
<div itemprop="itemOffered" itemscope="" itemtype="http://schema.org/Service" class="lp3-service-frame-inner">
<div class="service-image">
<a href="#"><img itemprop="image" alt="Double door fridge repair" src="https://homexrepair.com/img/double-door-fridge-repair.png"></a>
</div>
  <div class="service-label"><p itemporp="name">Double door refrigerator repair</p></div>
<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button" itemscope="" itemtype="http://schema.org/LocalBusiness"><a itemprop="telephone" href="tel:18008330206">CALL NOW</a></div>
</div>
</div>
</div>

<div class="lp3-service-frame service-frame3">
<div itemprop="itemOffered" itemscope="" itemtype="http://schema.org/Service" class="lp3-service-frame-inner">
<div class="service-image top-load-image">
<a href="#"><img itemprop="image" alt="Side by side door fridge repair" src="https://homexrepair.com/img/side-by-side-fridge-repair.png"></a>
</div>
<div class="service-label"><p itemporp="name">Side by side door refrigerator repair</p></div>

<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button" itemscope="" itemtype="http://schema.org/LocalBusiness"><a itemprop="telephone" href="tel:18008330206">CALL NOW</a></div>

</div>
</div>
</div>
</div>
</section>