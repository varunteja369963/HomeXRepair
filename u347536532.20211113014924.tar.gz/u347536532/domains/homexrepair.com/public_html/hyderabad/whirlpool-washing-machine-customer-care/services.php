<section class="lp3-service-section">
<div class="service-section-label"><p>Category Of Washing Machine Repair Services</p></div>
<div class="lp3-three-service-frames">
<div class="lp3-service-frame service-frame1">
<div class="lp3-service-frame-inner">
<div class="service-image top-load-image">
<a href="#"><img alt="Fully Automatic Top Load Washing Machine Repair" src="https://homexrepair.com/img/fully-automatic-top-load-washing-machine-repair.png" loading="lazy"></a>
</div>
  <div class="service-label"><p>Fully Automatic Top Load Washing Machine Repair</p></div>
<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button"><a href="tel:18008330206">CALL NOW</a></div>

</div>
</div>
</div>
<div class="lp3-service-frame service-frame2">
<div class="lp3-service-frame-inner">
<div class="service-image">
<a href="#"><img alt="Fully Automatic Front Load Washing Machine Repair" src="https://homexrepair.com/img/fully-automatic-front-load-washing-machine-repair.png" loading="lazy"></a>
</div>
  <div class="service-label"><p>Fully Automatic Front Load Washing Machine Repair</p></div>
<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button"><a href="tel:18008330206">CALL NOW</a></div>
</div>
</div>
</div>

<div class="lp3-service-frame service-frame3">
<div class="lp3-service-frame-inner">
<div class="service-image top-load-image">
<a href="#"><img alt="Semi Automatic Top Load Washing Machine Repair" src="https://homexrepair.com/img/semi-automatic-top-load-washing-machine-repair.png" loading="lazy"></a>
</div>
<div class="service-label"><p>Semi Automatic Top Load Washing Machine Repair</p></div>

<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button"><a href="tel:18008330206">CALL NOW</a></div>

</div>
</div>
</div>
</div>
</section>