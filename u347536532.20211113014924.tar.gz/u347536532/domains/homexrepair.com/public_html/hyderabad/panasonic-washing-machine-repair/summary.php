<section class="lp3-summary-section">
    <div class="lp3-summary lp3-fridge-summary">
     
        <img class = "lp3-summary-fridge-image" srcset="https://homexrepair.com/img/washing-machine-repair-mobile.jpg 400w,
             https://homexrepair.com/img/washing-machine-repair-service-desktop.jpg 800w" sizes="(max-width: 500px) 400px,
            800px" src="https://homexrepair.com/img/washing-machine-repair-service-desktop.jpg" alt="Panasonic Washing Machine Repair Service In Hyderabad" title="Panasonic Washing Machine Repair">
         
        <div class="lp3-banner-black-background">
              <div class="lp3-banner-black-background-inner"> 
              <h1 class="heading">Panasonic Washing Machine Repair Service</h1>
            </div>
        </div>
    </div>
</section>
