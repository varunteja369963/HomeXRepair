<nav class="nav">
<button type="button" id="menu-icon" class="menu-icon"><i class="fa fa-bars"></i></button>
<div class="nav-inner">
<div itemscope="" itemtype="http://schema.org/Brand" class="logo">
<a href="https://homexrepair.com" follow="dofollow">Home<span>X</span>Repair</a>
</div>
<div class="menu" id="menu">
<ul class="menu-ul">
<li><a href="https://homexrepair.com" follow="dofollow">Home</a></li>
<li><a href="https://homexrepair.com/about/" follow="dofollow">About</a></li>
<li><a href="https://homexrepair.com/contact/#get-quote" follow="dofollow">Get Quote</a></li>
<li><a href="https://homexrepair.com/contact/" follow="dofollow">Contact</a></li>
</ul>
</div>

<div class="mobile-menu" id="mobile-menu" style="display: none;">
<button type="button" id="close-nav" class="close-nav" style="display: none;"><i class="fa fa-close"></i></button>
<ul class="menu-ul">
<li><a href="https://homexrepair.com" follow="dofollow">Home</a></li>
<li><a href="https://homexrepair.com/about/" follow="dofollow">About</a></li>
<li><a href="https://homexrepair.com/contact/#get-quote" follow="dofollow">Get Quote</a></li>
<li><a href="https://homexrepair.com/contact/" follow="dofollow">Contact</a></li>
</ul>
</div>
</div>
</nav>