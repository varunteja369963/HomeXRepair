<section class="modal-box-section" id="modal-box-section">
  <div class="modal-box-div">
  <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close-header close-popup" id="close-header-popup">×</button>
            </div>
            <div class="modal-body">
              <p>Successfully submited. We will reach you out shortly.</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="close-footer close-popup" id="close-footer-popup">Close</button>
            </div>
    </div>
          </div>  
</section>