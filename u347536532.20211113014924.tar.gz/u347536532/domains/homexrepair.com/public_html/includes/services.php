<section class="service-section" itemscope="" itemtype="http://schema.org/Service">
<div class="service-section-label"><p>Our Services</p></div>
<div class="four-service-frames">
<div class="two-service-frames two-service-frame1">
<div class="service-frame service-frame1">
<div class="service-frame-inner" itemprop="itemOffered" itemscope="" itemtype="http://schema.org/Service">
<div class="service1-image service-image">
<a href="#"><img itemprop="image" alt="Washing machine repair service provided by HomeXRepair" src="https://homexrepair.com/img/washing-machine-repair.png"></a>
</div>
  <div class="service-label"><p itemporp="name">Washing Machine Repair</p></div>
<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button" itemscope="" itemtype="http://schema.org/LocalBusiness"><a itemprop="telephone" href="tel:18008330206">CALL NOW</a></div>

</div>
</div>
</div>
<div class="service-frame service-frame2">
<div class="service-frame-inner" itemprop="itemOffered" itemscope="" itemtype="http://schema.org/Service">
<div class="service-image fridge-image">
<a href="#"><img itemprop="image" alt="Fridge repair services provided by homexrepair" src="https://homexrepair.com/img/fridge-repair.png"></a>
</div>
  <div class="service-label"><p itemporp="name">Fridge Repair</p></div>
<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button" itemscope="" itemtype="http://schema.org/LocalBusiness"><a itemprop="telephone" href="tel:18008330206">CALL NOW</a></div>

</div>
</div>
</div>
</div>
<div class="two-service-frames two-service-frame2">
<div class="service-frame service-frame3">
<div class="service-frame-inner" itemprop="itemOffered" itemscope="" itemtype="http://schema.org/Service">
<div class="service-image">
<a href="#"><img itemprop="image" alt="Oven repair services provided by HomeXRepair" src="https://homexrepair.com/img/oven-repair.png"></a>
</div>
<div class="service-label"><p itemporp="name">Microwave Oven Repair</p></div>

<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button" itemscope="" itemtype="http://schema.org/LocalBusiness"><a itemprop="telephone" href="tel:18008330206">CALL NOW</a></div>

</div>
</div>
</div>
<div class="service-frame service-frame4">
<div class="service-frame-inner" itemprop="itemOffered" itemscope="" itemtype="http://schema.org/Service">
<div class="service-image">
<a href="#"><img itemprop="image" alt="ac repair services provided by homexrepair" src="https://homexrepair.com/img/ac-repair.png"></a>
</div>
  <div class="service-label"><p itemporp="name">AC Repair</p></div>
<div class="service-contact-panel">
  <div class="get-quote-button"><a href="">Get Quote</a></div>
<div class="service-call-button" itemscope="" itemtype="http://schema.org/LocalBusiness"><a itemprop="telephone" href="tel:18008330206">CALL NOW</a></div>

</div>
</div>
</div>
</div>
</div>
</section>