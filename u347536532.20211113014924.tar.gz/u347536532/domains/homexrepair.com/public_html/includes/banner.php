<section class="lp2-banner-section">
    <div class="lp2-banner">
  <div class="lp2-banner-div">
  <div class="lp2-banner-div-inner">
        <div class="lp2-banner-heading-div"><h1 class="lp2-banner-heading"><?php echo $heading; ?></h1></div>
        <div class="lp2-banner-sub-heading"><p><?php echo $sub_heading; ?></p></div>
  </div>
  </div>
    </div>
</section>