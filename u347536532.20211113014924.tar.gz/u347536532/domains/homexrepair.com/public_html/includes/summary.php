<section class = "summary-section">
<div class = "summary">
<div class = "summary-info">
<div class = "summary-info-inner">
<div class = "heading-div"><h1 class = "heading">Hire home appliance repair technicians from HomeXRepair</h1></div>
<div class = "summary-matter">
<p>
Book appliance repair expert at your doorstep. Call or get quote for washing machine repair, fridge repair, ac repair and oven repair today. Services starting at only 249 INR with 3 months warranty on parts and 45 days warranty on repair. 
</p>
</div>
<div class = "call-now-div"><a href = "tel:18008330206">CALL NOW</a></div>
</div>
</div>

<div class = "illustration-image-section">
    <img class = "illustration-image" src = "https://homexrepair.com/img/homexrepair_banner.svg" alt = "HomeXRepair Home page Image"/>
</div>
</div>
</section>