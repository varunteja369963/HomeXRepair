
<section class = "popular-links-section">
<div class = "popular-links">
<div class = "popular-links-label"><p>People Who Visited This Page Also Visited</p></div>
<div class = "popular-links-buttons">
<button type = "button" id = "most-visited-button">Most Visited</button>
<button type = "button" id = "near-you-button">Near You</button>
<button type = "button" id = "brands-button">Brands</button>
<button type = "button" id = "areas-button">Areas</button>
</div>
<div class = "popular-links-a">
<div class = "most-visited-div" id = "most-visited-div">
<a href = "">Washing Machine Repair</a>&nbsp;&#124;
<a href = "">Refrigerator Repair</a>&nbsp;&#124;
<a href = "">Microwave Oven Repair</a>&nbsp;&#124;
<a href = "">Air Conditioner Repair</a>&nbsp;&#124;
</div>
<div class = "near-you-div" id = "near-you-div">
<a href = "">Washing Machine Repair Near me</a>&nbsp;&#124;
<a href = "">Refrigerator Repair Near me</a>&nbsp;&#124;
<a href = "">Microwave Oven Repair Near me</a>&nbsp;&#124;
<a href = "">Air Conditioner Repair Near me</a>&nbsp;&#124;
</div>
<div class = "brands-div" id = "brands-div">
<a href = "">Lg Washing Machine Repair</a>&nbsp;&#124;
<a href = "">Lg Refrigerator Repair</a>&nbsp;&#124;
<a href = "">Lg Microwave Oven Repair</a>&nbsp;&#124;
<a href = "">Lg AC Repair</a>&nbsp;&#124;
<a href = "">Samsung Washing Machine Repair</a>&nbsp;&#124;
<a href = "">Samsung Refrierator Repair</a>&nbsp;&#124;
<a href = "">Samsung Microwave Oven Repair</a>&nbsp;&#124;
<a href = "">Samsung AC Repair</a>&nbsp;&#124;
<a href = "">Whirlpool Washing Machine Repair</a>&nbsp;&#124;
<a href = "">Whirlpool Refrigerator Repair</a>&nbsp;&#124;
<a href = "">Whirlpool Microwave Oven Repair</a>&nbsp;&#124;
<a href = "">Whirlpool AC Repair</a>&nbsp;&#124;
<a href = "">Ifb Washing Machine Repair</a>&nbsp;&#124;
<a href = "">Ifb Refrigerator Repair</a>&nbsp;&#124;
<a href = "">Ifb Oven Repair</a>&nbsp;&#124;
<a href = "">Ifb AC Repair</a>&nbsp;&#124;
</div>
<div class = "areas-div" id = "areas-div">
<a href = "">Washing Machine Repair In Hyderabad</a>&nbsp;&#124;
<a href = "">Refrigerator Repair In Hyderabad</a>&nbsp;&#124;
<a href = "">Microwave Oven Repair In Hyderabad</a>&nbsp;&#124;
<a href = "">Air Conditioner Repair In Hyderabad</a>&nbsp;&#124;
</div>
</div>
</div>
</section>