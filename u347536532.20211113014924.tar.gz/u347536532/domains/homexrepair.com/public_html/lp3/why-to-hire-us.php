<section class="why-to-hire-us-section">
<div class="lp3-why-to-hire-us">
<div class="why-to-hire-us-label"><p>Why To Hire Us?</p></div>
<div class="why-to-hire-us-inner">

<div class="warranty-div left-div why-to-hire-us-box">
  <div class="why-to-hire-us-icons"><i class="fa fa-smile-o"></i></div>
<div class="warranty-content left-content">
  <div class="why-to-hire-us-label-numbers">3 Months</div>
<div class="warranty-label why-to-hire-us-inner-label"><p>Guarantee On Repair</p></div>

</div>
</div>

<div class="service-fee-div right-div why-to-hire-us-box">
  <div class="why-to-hire-us-icons"><i class="fa fa-money"></i></div>
<div class="service-fee-content right-content">
    <div class="why-to-hire-us-label-numbers"><span class="fa">&#8377;</span><span>249</span></div><div class="service-fee-label why-to-hire-us-inner-label"><p> Visiting Charges</p></div>
</div>
</div>

  <div class="experience-div right-div why-to-hire-us-box">
  <div class="why-to-hire-us-icons"><i class="fa fa-id-card-o"></i></div>
<div class="cancel-anytime-content right-content">
  <div class="why-to-hire-us-label-numbers">15+</div>
<div class="cancel-anytime-label why-to-hire-us-inner-label"><p>Years Of Experience</p></div>
</div>
</div>
</div>
</div>
</section>